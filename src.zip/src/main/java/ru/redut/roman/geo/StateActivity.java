package ru.redut.roman.geo;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.Arrays;

public class StateActivity extends AppCompatActivity {
    WebView webview;

    private final View.OnClickListener myClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            setContentView(R.layout.activity_state);
            String name = ((Button) view).getText().toString();
/*            AssetManager am = getAssets();
            try {
                am.list("file:///android_asset/"+name+".html");
            } catch (IOException e) {
                e.printStackTrace();
                name="404";
            }
 */
            webview = findViewById(R.id.webbrowser);
            webview.loadUrl("file:///android_asset/"+name+".html");
            LinearLayout layout = (LinearLayout) findViewById(R.id.state_layout);
            //layout.setVisibility(View.INVISIBLE);
            webview.setVisibility(View.VISIBLE);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_state);
        String btnText = getIntent().getStringExtra("text");
        StateList(btnText);
    }

    public void StateList(String letter) {
        LinearLayout layout = (LinearLayout) findViewById(R.id.state_layout);
        layout.setBackgroundColor(Color.LTGRAY);

        String[] letter_str = new String[]{"А", "Б", "В", "Г", "Д", "Е", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Э", "Ю", "Я"};
        int index = Arrays.asList(letter_str).indexOf(letter);

        Resources res = getResources();
        TypedArray sa = res.obtainTypedArray(R.array.statelist);
        int n = sa.length();
        //String[] array = new String[n];
        int id = sa.getResourceId(index, 0);
        String[] country_list = res.getStringArray(id);

        for (int i = 0; i < country_list.length; i++) {
            Button myButton = new Button(this);
            myButton.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
            myButton.setText(country_list[i]);
            myButton.setOnClickListener(myClickListener);

            layout.addView(myButton);
        }
//        setContentView(R.layout.activity_state);
    }

}
