package ru.redut.roman.geo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;

public class MainActivity extends Activity {

    private final View.OnClickListener myClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            goState(view);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        letterList();
    }

    public void goState(View view) {
         String text = ((Button) view).getText().toString();
         Intent intent = new Intent(this, StateActivity.class); // переходим на активность вывода списка стран
         intent.putExtra("text", text);
         startActivity(intent);
    }

        public void letterList () {
            String[] letter = new String[]{"А", "Б", "В", "Г", "Д", "Е", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "Т", "У", "Ф", "Х", "Ц", "Ч", "Ш", "Э", "Ю", "Я"};
            int count = letter.length; // number of buttons

            TableLayout tabLay = (TableLayout) findViewById(R.id.space_layout);
            tabLay.setBackgroundColor(Color.LTGRAY);

            for (int i = 0; i < 9; i++) {

                TableRow tr = new TableRow(this);
                TableLayout.LayoutParams rowParams = new TableLayout.LayoutParams(
                        TableLayout.LayoutParams.WRAP_CONTENT,
                        TableLayout.LayoutParams.WRAP_CONTENT,
                        1);
                tr.setLayoutParams(rowParams);

                for (int j = 0; j < 3; j++) {

                    TableRow.LayoutParams params = new TableRow.LayoutParams(
                            TableRow.LayoutParams.WRAP_CONTENT,
                            TableRow.LayoutParams.WRAP_CONTENT,
                            1);
                    Button btn = new Button(this); //getActivity()
                    btn.setLayoutParams(params);
                    btn.setText(letter[i + j + j * 8]);
                    btn.setOnClickListener(myClickListener);

                    tr.addView(btn, j);
                }
                tabLay.addView(tr, i);
            }
        }
}
